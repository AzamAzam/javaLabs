

public class Task2 {
    public static void main (String args[]) {
            AdressBook a=new AdressBook();
}
}
